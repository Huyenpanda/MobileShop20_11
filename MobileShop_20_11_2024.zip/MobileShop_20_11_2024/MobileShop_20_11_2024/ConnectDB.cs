﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileShop_20_11_2024
{
    internal class ConnectDB
    {
        SqlConnection conn = null;

        public ConnectDB()
        {
            string sql = "Data Source=LAPTOP-8BGH2AU5\\SQLEXPRESS;Initial Catalog=MobileShop;User ID=sa;Password=1235";
            conn = new SqlConnection(sql);
            try
            {
                conn.Open(); // Thử mở kết nối
                MessageBox.Show("Kết nối cơ sở dữ liệu thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối: " + ex.Message); // Hiển thị lỗi nếu kết nối thất bại
            }
        }

        public bool checkLogin(string username, string password)
        {
            try
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM NguoiDung WHERE tendangnhap = @username AND matkhau = @password";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);

                int result = (int)cmd.ExecuteScalar();
                return result > 0; // Nếu có ít nhất 1 dòng trả về, thông tin hợp lệ
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi: " + ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
        public DataSet getData(string sql)
        {
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi lấy dữ liệu: " + ex.Message);
                return null;
            }
            conn.Close();
        }

        public bool doTransaction(SqlCommand cmd)
        {
            try
            {
                conn.Open();
                cmd.Connection = conn;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public List<DonHang> GetDanhSachDonHang()
        {
            List<DonHang> donHangs = new List<DonHang>();
            string sql = "SELECT * FROM DonHang";
            DataSet ds = getData(sql); // Sử dụng phương thức getData để lấy dữ liệu

            if (ds != null && ds.Tables.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    DonHang donHang = DonHang.FromDataRow(row); // Chuyển mỗi dòng thành một đối tượng DonHang
                    donHangs.Add(donHang);
                }
            }

            return donHangs;
        }




    }
}
