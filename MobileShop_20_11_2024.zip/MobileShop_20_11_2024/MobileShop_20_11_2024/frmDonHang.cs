﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileShop_20_11_2024
{
    public partial class frmDonHang : Form
    {
        private ConnectDB db;

        public frmDonHang()
        {
            InitializeComponent();
            db = new ConnectDB(); // Khởi tạo db
        }

        private void frmDonHang_Load(object sender, EventArgs e)
        {
            LoadDanhSachDonHang();
        }

        // Hàm tải danh sách đơn hàng
        private void LoadDanhSachDonHang()
        {
            db = new ConnectDB();
            string sql = "SELECT * FROM DonHang";
            DataSet ds = db.getData(sql); // Gọi phương thức getData để lấy dữ liệu từ cơ sở dữ liệu
            if (ds != null)
                
            {
                dgvDonHang.DataSource = ds.Tables[0]; // Gán kết quả truy vấn vào DataGridView
                MessageBox.Show("Không co du lieu");
            }
            else
            {
                MessageBox.Show("Không thể tải dữ liệu.");
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string khachHangID = txtKhachHangID.Text.Trim();
            string sanPhamID = txtSanPhamID.Text.Trim();
            int soLuong = int.Parse(txtSoLuong.Text.Trim());
            DateTime ngayMua = dtpNgayMua.Value;

            string sql = "INSERT INTO DonHang (KhachHangID, SanPhamID, SoLuong, NgayMua) " +
                         "VALUES (@KhachHangID, @SanPhamID, @SoLuong, @NgayMua)";
            SqlCommand cmd = new SqlCommand(sql);
            cmd.Parameters.AddWithValue("@KhachHangID", khachHangID);
            cmd.Parameters.AddWithValue("@SanPhamID", sanPhamID);
            cmd.Parameters.AddWithValue("@SoLuong", soLuong);
            cmd.Parameters.AddWithValue("@NgayMua", ngayMua);

            bool success = db.doTransaction(cmd);
            if (success)
            {
                MessageBox.Show("Thêm đơn hàng thành công!");
                LoadDanhSachDonHang(); // Cập nhật lại danh sách đơn hàng
            }
            else
            {
                MessageBox.Show("Có lỗi xảy ra khi thêm đơn hàng!");
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            string donHangID = txtDonHangID.Text.Trim();
            string khachHangID = txtKhachHangID.Text.Trim();
            string sanPhamID = txtSanPhamID.Text.Trim();
            int soLuong = int.Parse(txtSoLuong.Text.Trim());
            DateTime ngayMua = dtpNgayMua.Value;

            string sql = "UPDATE DonHang SET KhachHangID = @KhachHangID, SanPhamID = @SanPhamID, SoLuong = @SoLuong, NgayMua = @NgayMua " +
                         "WHERE DonHangID = @DonHangID";
            SqlCommand cmd = new SqlCommand(sql);
            cmd.Parameters.AddWithValue("@DonHangID", donHangID);
            cmd.Parameters.AddWithValue("@KhachHangID", khachHangID);
            cmd.Parameters.AddWithValue("@SanPhamID", sanPhamID);
            cmd.Parameters.AddWithValue("@SoLuong", soLuong);
            cmd.Parameters.AddWithValue("@NgayMua", ngayMua);

            bool success = db.doTransaction(cmd);
            if (success)
            {
                MessageBox.Show("Sửa đơn hàng thành công!");
                LoadDanhSachDonHang(); // Cập nhật lại danh sách đơn hàng
            }
            else
            {
                MessageBox.Show("Có lỗi xảy ra khi sửa đơn hàng!");
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string donHangID = txtDonHangID.Text.Trim();

            string sql = "DELETE FROM DonHang WHERE DonHangID = @DonHangID";
            SqlCommand cmd = new SqlCommand(sql);
            cmd.Parameters.AddWithValue("@DonHangID", donHangID);

            bool success = db.doTransaction(cmd);
            if (success)
            {
                MessageBox.Show("Xóa đơn hàng thành công!");
                LoadDanhSachDonHang(); // Cập nhật lại danh sách đơn hàng
            }
            else
            {
                MessageBox.Show("Có lỗi xảy ra khi xóa đơn hàng!");
            }
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim();
            string sql = "SELECT * FROM DonHang WHERE DonHangID LIKE @SearchText OR KhachHangID LIKE @SearchText";
            SqlCommand cmd = new SqlCommand(sql);
            cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

            DataSet ds = db.getData(sql); // Truyền chuỗi SQL vào thay vì SqlCommand
            if (ds != null)
            {
                dgvDonHang.DataSource = ds.Tables[0]; // Hiển thị kết quả tìm kiếm trên DataGridView
            }
            else
            {
                MessageBox.Show("Không có kết quả tìm kiếm.");
            }
        }
    }

}
