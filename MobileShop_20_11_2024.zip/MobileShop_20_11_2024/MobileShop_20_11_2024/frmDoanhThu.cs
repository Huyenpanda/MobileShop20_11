﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileShop_20_11_2024
{
    public partial class frmDoanhThu : Form
    {
        private ConnectDB db;
        public frmDoanhThu()
        {
            InitializeComponent();
        }

        private void frmDoanhThu_Load(object sender, EventArgs e)
        {
            LoadDoanhThuTheoThang(); // Tải dữ liệu doanh thu theo tháng khi form được mở
        }
        private void LoadDoanhThuTheoThang()
        {
            // Truy vấn SQL để lấy doanh thu theo tháng
            string sql = @"
        SELECT 
            YEAR(DH.ngaymua) AS Year,
            MONTH(DH.ngaymua) AS Month,
            SUM(DH.soluong * SP.gia) AS DoanhThu
        FROM DonHang DH
        JOIN SanPham SP ON DH.sanphamid = SP.id
        GROUP BY YEAR(DH.ngaymua), MONTH(DH.ngaymua)
        ORDER BY YEAR(DH.ngaymua), MONTH(DH.ngaymua)";

            DataSet ds = db.getData(sql); // Gọi phương thức getData để lấy dữ liệu
            if (ds != null && ds.Tables.Count > 0)
            {
                dgvDoanhThu.DataSource = ds.Tables[0]; // Hiển thị kết quả trong DataGridView
            }
            else
            {
                MessageBox.Show("Không có dữ liệu doanh thu.");
            }
        }


    }
}
