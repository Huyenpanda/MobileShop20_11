﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileShop_20_11_2024
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Xác nhận thoát ứng dụng
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát không?",
                                                  "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No)
            {
                e.Cancel = true; // Hủy sự kiện đóng form
            }
        }

        // Sự kiện click cho "Đơn hàng"
        private void donHangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Mở form quản lý đơn hàng
            frmDonHang frmDH = new frmDonHang();
            frmDH.ShowDialog();
        }

        private void doanhThuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Mở form quản lý đơn hàng
            frmDoanhThu frmDT = new frmDoanhThu();
            frmDT.ShowDialog();
        }
    }
}
