﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileShop_20_11_2024
{
    public partial class FormDangNhap : Form
    {
        ConnectDB db = new ConnectDB(); // Kết nối đến cơ sở dữ liệu
        public FormDangNhap()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            // Kiểm tra thông tin đăng nhập
            if (db.checkLogin(username, password))
            {
                MessageBox.Show("Đăng nhập thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Mở Form Main
                frmMain mainForm = new frmMain();
                this.Hide(); // Ẩn form đăng nhập
                mainForm.ShowDialog(); // Hiển thị form chính
                this.Show(); // Hiển thị lại form đăng nhập sau khi đóng form chính
            }
            else
            {
                if (!db.checkLogin(username, password))
                {
                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng!", "Lỗi đăng nhập", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            // Cho phép đăng nhập khi nhấn Enter
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin.PerformClick();
            }
        }
    }
}
