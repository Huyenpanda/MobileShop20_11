﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileShop_20_11_2024
{
    public class DonHang
    {
        public string DonHangID { get; set; }
        public string KhachHangID { get; set; }
        public string SanPhamID { get; set; }
        public int SoLuong { get; set; }
        public DateTime NgayMua { get; set; }

        public DonHang(string donHangID, string khachHangID, string sanPhamID, int soLuong, DateTime ngayMua)
        {
            DonHangID = donHangID;
            KhachHangID = khachHangID;
            SanPhamID = sanPhamID;
            SoLuong = soLuong;
            NgayMua = ngayMua;
        }

        // Hàm chuyển dữ liệu từ DataRow thành đối tượng DonHang
        public static DonHang FromDataRow(DataRow row)
        {
            return new DonHang(
                row["DonHangID"].ToString(),
                row["KhachHangID"].ToString(),
                row["SanPhamID"].ToString(),
                Convert.ToInt32(row["SoLuong"]),
                Convert.ToDateTime(row["NgayMua"])
            );
        }
    }

}
